"""
Unit tests for the secret sharing scheme.
Testing secret sharing is not obligatory.

MODIFY THIS FILE.
"""


def test():
    raise NotImplementedError("You can create some tests.")
